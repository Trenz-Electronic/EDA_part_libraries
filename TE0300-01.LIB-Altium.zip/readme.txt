----------------------------------------------------------------
This archive is copyrighted Trenz Electronic GmbH.
For updates visit www.trenz-electronic.de
Contact: info@trenz-electronic.de
----------------------------------------------------------------
Content: Design Ressources for Spartan-3E Industrial Micromodule
----------------------------------------------------------------

* Protel schematic library saved in Version 4.0 format
  File: TE0300-01 Support Files AltiumDesigner\TE0300-01-SCH.lib

* Protel PCB library saved in Version 3.0 format
  File: TE0300-01 Support Files AltiumDesigner\TE0300-01-PCB.lib

* Gerber data of TE0300-01 Footprint
  Files: Gerber\*.*
